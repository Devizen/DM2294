<?xml version="1.0" encoding="UTF-8" ?>
<tileset name="tiles" tilewidth="16" tileheight="16" spacing="1">
   <image source="../tiles.png" width="407" height="254"/>
</tileset>
