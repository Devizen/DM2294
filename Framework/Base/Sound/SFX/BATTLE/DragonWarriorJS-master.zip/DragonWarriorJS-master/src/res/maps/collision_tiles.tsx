<?xml version="1.0" encoding="UTF-8" ?>
<tileset name="collision" tilewidth="16" tileheight="16" spacing="1">
   <image source="../collision.png" width="50" height="50"/>
</tileset>
