dw.Sounds = Object.freeze({
   MUSIC_TITLE_SCREEN: 'titleMusic',
   MUSIC_TANTEGEL: 'tantegelMusic',
   MUSIC_TANTEGEL_LOWER: 'tangelLowerMusic',
   MUSIC_OVERWORLD: 'overworldMusic',
   MUSIC_BATTLE: 'battleMusic',
   MUSIC_TOWN: 'villageMusic',
   MUSIC_DUNGEON_FLOOR_1: 'dungeonFloor1'
});
