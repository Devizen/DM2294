dw.NpcType = Object.freeze({
   SOLDIER_GRAY: 0,
   SOLDIER_RED: 1,
   MAN_BLUE: 2,
   WOMAN_BLUE: 3,
   MERCHANT_GREEN: 4,
   OLD_MAN_GRAY: 5
});
