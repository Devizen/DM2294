#include "TreasureChest.h"

CTreasureChest::CTreasureChest(void)
{
}

CTreasureChest::~CTreasureChest(void)
{
}
